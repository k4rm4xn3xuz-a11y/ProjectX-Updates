$ErrorActionPreference = 'Stop'

$clientDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$clientExe = Join-Path $clientDir '1.metin2client.exe'
$updateConfig = Join-Path $clientDir 'update-config.json'

function Update-ProjectXClient {
    if (-not (Test-Path -LiteralPath $updateConfig -PathType Leaf)) { return }

    $cfg = Get-Content -LiteralPath $updateConfig -Raw | ConvertFrom-Json
    if ([string]::IsNullOrWhiteSpace($cfg.manifestUrl) -or $cfg.manifestUrl -like '*CHANGE-ME*') { return }

    $manifest = Invoke-RestMethod -Uri $cfg.manifestUrl -Method Get -UseBasicParsing
    if (-not $manifest.files) { throw 'Update-Manifest enthält keine Dateien.' }

    $tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('ProjectXUpdate-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
    try {
        foreach ($entry in $manifest.files) {
            $relative = [string]$entry.path
            if ([string]::IsNullOrWhiteSpace($relative) -or [IO.Path]::IsPathRooted($relative) -or $relative.Contains('..')) {
                throw "Ungültiger Update-Pfad: $relative"
            }
            $target = Join-Path $clientDir $relative
            if (Test-Path -LiteralPath $target -PathType Leaf) {
                $localHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
                if ($localHash -eq ([string]$entry.sha256).ToLowerInvariant()) { continue }
            }
            $download = Join-Path $tempRoot $relative
            New-Item -ItemType Directory -Path (Split-Path $download) -Force | Out-Null
            Invoke-WebRequest -Uri ([string]$entry.url) -OutFile $download -UseBasicParsing
            $hash = (Get-FileHash -LiteralPath $download -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($hash -ne ([string]$entry.sha256).ToLowerInvariant()) {
                throw "Hash-Prüfung fehlgeschlagen: $relative"
            }
            New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
            Move-Item -LiteralPath $download -Destination ($target + '.update') -Force
        }
        foreach ($entry in $manifest.files) {
            $target = Join-Path $clientDir ([string]$entry.path)
            Move-Item -LiteralPath ($target + '.update') -Destination $target -Force
        }
    }
    finally {
        if (Test-Path -LiteralPath $tempRoot) { Remove-Item -LiteralPath $tempRoot -Recurse -Force }
    }
}

Update-ProjectXClient

if (-not (Test-Path -LiteralPath $clientExe -PathType Leaf)) {
    throw "Client nicht gefunden: $clientExe"
}

Add-Type @'
using System;
using System.Runtime.InteropServices;

public static class ProjectXWindowNative {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, uint flags);

    [DllImport("user32.dll")]
    public static extern int GetSystemMetrics(int nIndex);
}
'@

$process = Start-Process -FilePath $clientExe -WorkingDirectory $clientDir -PassThru
$deadline = (Get-Date).AddSeconds(45)

do {
    Start-Sleep -Milliseconds 250
    $process.Refresh()
    $handle = $process.MainWindowHandle
} while ($handle -eq [IntPtr]::Zero -and -not $process.HasExited -and (Get-Date) -lt $deadline)

if ($handle -eq [IntPtr]::Zero) {
    throw 'Das Metin2-Fenster wurde nicht rechtzeitig gefunden.'
}

$gwlStyle = -16
$wsThickFrame = 0x00040000
$wsMinimizeBox = 0x00020000
$wsMaximizeBox = 0x00010000
$swpFrameChanged = 0x0020
$sized = $false

# Das Spiel kann den Stil kurz nach dem Start neu setzen. Deshalb überwachen wir
# den Prozess und setzen WS_THICKFRAME dauerhaft, solange das Spiel läuft.
while (-not $process.HasExited) {
    $process.Refresh()
    $handle = $process.MainWindowHandle
    if ($handle -ne [IntPtr]::Zero) {
        $style = [ProjectXWindowNative]::GetWindowLongPtr($handle, $gwlStyle).ToInt64()
        $newStyle = $style -bor $wsThickFrame -bor $wsMinimizeBox -bor $wsMaximizeBox
        [ProjectXWindowNative]::SetWindowLongPtr($handle, $gwlStyle, [IntPtr]::new($newStyle)) | Out-Null
        [ProjectXWindowNative]::SetWindowPos($handle, [IntPtr]::Zero, 0, 0, 0, 0, $swpFrameChanged -bor 0x0001 -bor 0x0002 -bor 0x0004) | Out-Null

        if (-not $sized) {
            $screenWidth = [ProjectXWindowNative]::GetSystemMetrics(0)
            $screenHeight = [ProjectXWindowNative]::GetSystemMetrics(1)
            $width = [Math]::Min(1280, $screenWidth - 80)
            $height = [Math]::Min(720, $screenHeight - 120)
            $x = [Math]::Max(0, [int](($screenWidth - $width) / 2))
            $y = [Math]::Max(0, [int](($screenHeight - $height) / 2))
            [ProjectXWindowNative]::SetWindowPos($handle, [IntPtr]::Zero, $x, $y, $width, $height, $swpFrameChanged) | Out-Null
            $sized = $true
        }
    }
    Start-Sleep -Milliseconds 500
}
