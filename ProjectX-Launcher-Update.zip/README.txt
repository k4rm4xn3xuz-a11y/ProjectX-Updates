Einmalig alle Dateien in den bestehenden ProjectX-Client-Ordner kopieren. Danach Start_ProjectX_resizable.cmd verwenden. Keine Neuinstallation des Spiels erforderlich.
